import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Estado  {
	private HashMap<Integer,Integer> m = new HashMap<Integer,Integer>();
	private Estado pai;
	private int f,g,hlinha;
	private int[] h2 = {0,1,2,3,7,11,15,14,13,12,8,4,5,6,7,10,9};
	 
	
	
	public HashMap<Integer, Integer> getM() {
		return m;
	}
	public void setM(HashMap<Integer, Integer> m) {
		this.m = m;
	}
	public Estado getPai() {
		return pai;
	}
	public void setPai(Estado pai) {
		this.pai = pai;
	}
	
	
	public void insereMPos(int posicao,int valor){
		m.put(posicao, valor);
	}
	
	public int lerMPos(int posicao){
		return this.m.get(posicao);
	}
	
	public boolean comparaMatriz(Estado estado){
		for(int i=1;i<16;i++){
			if(m.get(i)!=estado.getM().get(i)){
				return false;
			}
		}
		
		return true;
	}
	
	public ArrayList<Estado> gerarFilhos(int tipo,Estado finale){
		Estado e1,e2,e3,e4;
		ArrayList<Estado> estados = new ArrayList<Estado>();
		
			e1 = new Estado();
			e1.setM(copiaM());
			e1.setG(this.getG());
			e1.moveAbaixo();
			e1.setPai(this);
			e1.calculaHlinha(tipo, finale);
			e1.calculaF();
			
			if(!e1.comparaMatriz(this)){
				estados.add(e1);
			}
			
			e2 = new Estado();
			e2.setM(copiaM());
			e2.setG(this.getG());
			e2.moveAcima();
			e2.setPai(this);
			e2.calculaHlinha(tipo, finale);
			e2.calculaF();
			
			if(!e2.comparaMatriz(this)){
				estados.add(e2);
			}
			
			
			e3 = new Estado();
			e3.setM(copiaM());
			e3.setG(this.getG());
			e3.moveDireita();
			e3.setPai(this);
			e3.calculaHlinha(tipo, finale);
			e3.calculaF();
			
			if(!e3.comparaMatriz(this)){
				estados.add(e3);
			}
			
			e4 = new Estado();
			e4.setM(copiaM());
			e4.setG(this.getG());
			e4.moveEsquerda();
			e4.setPai(this);
			e4.calculaHlinha(tipo, finale);
			e4.calculaF();
			
			if(!e4.comparaMatriz(this)){
				estados.add(e4);
			}
			
		
		
		return estados;
	}
	
	
	public void calculaHlinha(int tipo,Estado estado){
		switch (tipo) {
		case 1:
			this.setHlinha(calculaHalinha1(estado));
			break;

		case 2:this.setHlinha(calculaHalinha2(estado));
			break;
			
		case 3:	this.setHlinha(calculaHalinha3(estado));
			break;
		case 4: this.setHlinha(calculaHalinha4(estado));
			break;
		case 5: this.setHlinha(calculaHalinha5(estado));
			break;
		}
	}
	
	private int calculaHalinha5(Estado estado) {
		// TODO Auto-generated method stub
		return 0;
	}
	private int calculaHalinha4(Estado estado) {
		// TODO Auto-generated method stub
		return 0;
	}
	private int calculaHalinha3(Estado estado) {
		int posR,x,y,xM,yM,resultado=0;
		for(int i=1;i<16;i++){
				posR = localiza(m.get(i), estado);
				x = posR % 4;
				xM = i % 4;
				xM = xM - x;
				
				if(xM<0)
					xM = xM *(-1);
				
				y = achaColuna(m.get(i), estado);
				yM = achaColuna(m.get(i), this);
				
				yM = yM - y;
				
				if(yM<0)
					yM = yM * (-1);
				
				resultado = resultado + yM+ xM;
				
		}
		
		return resultado;
		
	}
	
	private int calculaHalinha2(Estado estado) {
		int contador = 0;
		 
		
		for(int i=1;i<16;i++){
			if(m.get(h2[i])!=m.get(h2[i-1])+1){
				contador++;
			}
		}
		
		return contador;
		
	}
	private int calculaHalinha1(Estado estado) {
		int contador = 0;
		HashMap<Integer,Integer> n = estado.getM(); 
		
		for(int i=0;i<16;i++){
			if(m.get(i)!=n.get(i)){
				contador++;
			}
		}
		
		return contador;
		
	}
	public void calculaF(){
		this.f = this.g + this.hlinha;
	}
	
	
	
	public void moveAcima(){
		int zero = achaZero();
		int aux = 0;
		
		if(zero>=4){
			aux = zero % 4;
		} else{
			aux = zero;
		} 
		
		if(aux != 0){
			int x = m.get(zero-1);
			m.put(zero-1, m.get(zero));
			m.put(zero, x);
			this.setG(this.getG()+1);
		}
		
	}
	
	public void moveAbaixo(){
		int zero = achaZero();
		int aux = 0;
		
		if(zero>=4){
			aux = zero % 4;
		}else{
			aux = zero;
		} 
		
		if(aux != 3){
			int x = m.get(zero+1);
			m.put(zero+1, m.get(zero));
			m.put(zero, x);
			this.setG(this.getG()+1);
		}
	}
	
	public void moveDireita(){
		int zero = achaZero();
			 
	
		if(zero <  12){
			int x = m.get(zero+4);
			m.put(zero+4, m.get(zero));
			m.put(zero, x);
			this.setG(this.getG()+1);
		}
	}
	
	public void moveEsquerda(){
		int zero = achaZero();
		 
		
		if(zero >=  4){
			int x = m.get(zero-4);
			m.put(zero-4, m.get(zero));
			m.put(zero, x);
			this.setG(this.getG()+1);
		}
	}
	
	public int getF() {
		return f;
	}
	public void setF(int f) {
		this.f = f;
	}
	public int getG() {
		return g;
	}
	public void setG(int g) {
		this.g = g;
	}
	public int getHlinha() {
		return hlinha;
	}
	public void setHlinha(int hlinha) {
		this.hlinha = hlinha;
	}
	
	public void imprimiTabela(){
		for(int i=0;i<16;i++){
			
				System.out.println(m.get(i));
			
		}
	}
	
	public int achaZero(){
		for(int i=0;i<16;i++){
			if(m.get(i)==0){
				return i;
			}
		}
		
		return -1;
	}
	
	public int localiza(int valor,Estado estado){
		
		for(int i=0;i<16;i++){
			if(estado.getM().get(i)==valor){
				return i;
			}
		}
		
		return -1;
	}
	
	public int achaColuna(int valor,Estado estado){
		int x = localiza(valor, estado);
		
		if(x < 4)
			return 0;
		if(x>=4 && x<8)
			return 1;
		if(x>=8 && x<12)
			return 2;
		if(x>=12 && x<16)
			return 3;
		return -1;
		
	}
	
	public HashMap<Integer,Integer> copiaM(){
		HashMap<Integer, Integer> mzinho = new HashMap<Integer,Integer>();
		
		for(int i=0;i<16;i++){
		
			mzinho.put(i, m.get(i));
		
		}
		
		return mzinho;
		
	}
	
}
