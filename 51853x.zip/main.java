import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class main {

	static final int tipo = 1;

	public static HashMap<Integer,Integer> entrada(){
		HashMap<Integer,Integer> m = new HashMap<Integer,Integer>(); 
		HashMap<Integer,Integer> n = new HashMap<Integer,Integer>();
		int x,aux[]={0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15};
		try {
			Scanner leitura = new Scanner(System.in);

			for(int i=0;i<16;i++){
				x = leitura.nextInt();
				m.put(i, x);

			}
			
			for(int j=0;j<16;j++){
				n.put(j, m.get(aux[j]));
			}
			
			
			return n;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return m;

	}

	public static boolean verificaTabela(Estado e, ArrayList<Estado> estados){
		
		for(int i=0;i<estados.size();i++){
			if(e.comparaMatriz(estados.get(i)))
				return true;
		}
		
		return false;
		
	}
	
	public static int retornaInt(Estado e, ArrayList<Estado> estados){
		
		for(int i=0;i<estados.size();i++){
			if(e.comparaMatriz(estados.get(i)))
				return i;
		}
		
		return -1;
		
	}
	
	public static Estado achaMin(ArrayList<Estado> estados){
		Estado menor = estados.get(0);
		for(int i=0;i<estados.size();i++){
			if(estados.get(i).getF() < menor.getF()){
				menor = estados.get(i);
			}
		}
		return menor;

	}

	public static void main(String[] args){
		long tempoInicio = System.currentTimeMillis();

		ArrayList<Estado> abertos = new ArrayList<Estado>();
		ArrayList<Estado> fechados= new ArrayList<Estado>();
		ArrayList<Estado> iniciais= new ArrayList<Estado>();
		ArrayList<Estado> finais= new ArrayList<Estado>();


		Estado menor,filho;



		Estado finale = new Estado();

		finale.insereMPos(0, 1);
		finale.insereMPos(1, 2);
		finale.insereMPos(2, 3);
		finale.insereMPos(3, 4);
		finale.insereMPos(4, 12);
		finale.insereMPos(5, 13);
		finale.insereMPos(6, 14);
		finale.insereMPos(7, 5);
		finale.insereMPos(8, 11);
		finale.insereMPos(9, 0);
		finale.insereMPos(10, 15);
		finale.insereMPos(11, 6);
		finale.insereMPos(12, 10);
		finale.insereMPos(13, 9);
		finale.insereMPos(14, 8);
		finale.insereMPos(15, 7);

		Estado e = new Estado();
		e.setM(entrada());

		iniciais.add(e);

		//a)
		abertos.add(e);

		for(int i=0;i<abertos.size();i++){
			abertos.get(i).calculaHlinha(tipo,finale);
			abertos.get(i).setG(0);
			abertos.get(i).calculaF();
		}

		//b)
		while(!abertos.isEmpty()){

			menor = achaMin(abertos);
			fechados.add(menor);
			abertos.remove(abertos.indexOf(menor));

			if(menor.comparaMatriz(finale)){
				System.out.println(menor.getG());
				System.out.println("Tempo Total: "+(System.currentTimeMillis()-tempoInicio));
				System.exit(0);
			}else{
				ArrayList<Estado> filhos = menor.gerarFilhos(tipo,finale);
				
				for(int i=0;i<filhos.size();i++){
					if(verificaTabela(filhos.get(i), fechados))
						continue;
					
					if(!verificaTabela(filhos.get(i), abertos)){
						abertos.add(filhos.get(i));
					}else{
						if(filhos.get(i).getG() < abertos.get(retornaInt(filhos.get(i), abertos)).getG()){
							abertos.remove(retornaInt(filhos.get(i), abertos));
							abertos.add(filhos.get(i));
						}
					}
				}
			}	

			
		}
		if(abertos.isEmpty())
			System.exit(1);
		System.exit(0);


	}

	private static boolean verificaClausula(ArrayList<Estado> abertos, ArrayList<Estado> fechados, Estado filho) {
		
		int aux;
		boolean a=false,b=false;
		
		if((verificaTabela(filho, abertos) || verificaTabela(filho, fechados))){
			a = true;
			
			if(verificaTabela(filho, abertos)){
				aux = retornaInt(filho, abertos);
				if(filho.getG()< abertos.get(aux).getG())
					b = true;
			}
			
			if(verificaTabela(filho, fechados)){
				aux = retornaInt(filho, fechados);
				
				if(filho.getG()< fechados.get(aux).getG())
					b = true;
			}
		}
		
		return a && b;
	}




}
